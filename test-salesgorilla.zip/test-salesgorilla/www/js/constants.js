var constants = {
  gcm: {
    senderId: '39644499677',
    pushServiceURL: 'http://gorilla.lucep.com'
  }
};