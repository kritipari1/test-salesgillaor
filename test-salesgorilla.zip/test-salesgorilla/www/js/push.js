push = window.push || {}; //TODO complete failure of naming

push.gcm = function (sender_id, push_service_url, opts) {
  this._sender_id = sender_id;
  this._push_service_url = push_service_url;
  this._opts = opts;
};

push.gcm.prototype.register = function () {
  return new Promise(function(resolve, reject) {
    if (PushNotification) {
      this._push = PushNotification.init({
        android: {
          senderID: "39644499677" //TODO hard-coding
        },
        browser: {
          pushServiceURL: 'http://gorilla.lucep.com' //TODO hard-coding
        }
      });
    } else {
      reject(this._error('PushNotification plugin not installed'));
    }
  });
};

push._error = function (msg, id) { //TODO why?
  return new Error('[push] ' + msg, id);
};