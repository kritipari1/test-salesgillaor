var qms_tellerapp = {
        "team_enabled": true,
        "protocol": "https",
        "domain": "gorilla.lucep.com" //"gorilla.lucep.com" //TODO hardcoded server URL
      };

var websocket_channel;
var websocket_channel_polling_fallback;
var auth_data = {};
var push_data ={ push_server: "https://gorilla.lucep.com/", //"https://gorilla.lucep.com/", //TODO hardcoded server URL
                 gcm_sender_id : "39644499677" };
var leads = { waiting: [], saved: [] };
var tabs = {
	"leadslist": { "tabbar_icon_class": "icon-home" },
	"leaddetails": { "tabbar_icon_class": "icon-user", "no_tab": true },
	"groupactivity": { "tabbar_icon_class": "icon-users" },
	"licenselimits": { "tabbar_icon_class": "icon-stripe", "no_tab": true}
};

var analytics_cache_time = 5 * 24 * 60 * 60 * 1000; //5 days

function is_element_in_viewport(el) {
	var rect = el.getBoundingClientRect();

	return (
		rect.top >= 0 &&
			rect.left >= 0 &&
			rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
		rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
	);
}

function on_visibility_change(el, callback) {
	var prev_visible;
	return function () {
		var curr_visible = is_element_in_viewport(el);
		if (curr_visible != prev_visible) {
			prev_visible = curr_visible;
			if (typeof callback == 'function') {
				callback(curr_visible);
			}
		}
	}
}

function set_state(state, persist) {
	if (state && typeof state === "object") {
		qms_tellerapp = BL.list.mergeinplace(qms_tellerapp, state);
		if (persist) {
			localStorage.setItem('app-data', JSON.stringify(qms_tellerapp));
		}
	}
}

function get_state(key) {
	return qms_tellerapp[key];
}

function get_ordinal(n, include_number) {
	if (typeof n === 'string') {
		n = parseInt(n);
	}

	var s=["th","st","nd","rd"],
    v=n%100;
	return n+(s[(v-20)%10]||s[v]||s[0]);
}

function get_host() {
	if (qms_tellerapp.domain) {
		var host = qms_tellerapp.protocol + "://" + qms_tellerapp.domain;
		if (qms_tellerapp.port) {
			host += ":" + qms_tellerapp.port;
		}
	} else {
		host = document.location.origin;
	}

	return host;
}

function api(a) {
	if (!a.uri && !a.url) {
		if (!auth_data || !auth_data.token) {
			screens.show.login();
		}

		a.host = get_host();
		a.websocket_params = a.websocket_params || { sender_socket_id: (websocket_channel ? websocket_channel._socket_id : null), exclude_sender: 0 };
	}

	if (!a.account_key && qms_tellerapp.account_key) {
		a.account_key = qms_tellerapp.account_key;
	}

	if (auth_data.token) {
		a.token = auth_data.token;
	}

	if (a.callback) {
		a.handlers.finish = a.callback;
		delete a.callback;
	}

	if (a.promisify) {
		var check_response_presence = function (response) {
			return new Promise(function (resolve, reject) {
				response ? resolve(response) : reject(new Error("No server response. Check URL & params"));
			});
		};

		var check_response_login_auth = function (response) {
			return new Promise(function (resolve, reject) {
				if (response.status === "login") {
					localStorage.removeItem("app-data");
					qms_tellerapp.auth_data = auth_data = {};
					screens.show.login(null, { error: E.lt("login-error") });

					reject(new Error("Unable to login due to invalid credentials"));
				} else {
					resolve(response);
				}
			});
		};

		var check_response_status = function (response) {
			return new Promise(function (resolve, reject) {
				if (response.status === "ok" || response.data) {
					resolve(response);
				} else {
					reject({ response: response, error: "API error :: [" + response.debug ? response.debug : response.status + "]" });
				}
			});
		};

		if (a.action === "login") {
			return E.qms.api(a)
				.then(check_response_presence);
		} else {
			return E.qms.api(a)
				.then(check_response_presence)
				.then(check_response_login_auth)
				.then(check_response_status);
		}
	} else {
		E.qms.api(a);
	}
}

function analytics(a) {
	a = BL.list.mergeinplace({
		url: null,
		action: "insight_parsed",
		token: qms_tellerapp.auth_data.token,
		account_key: null,
		customer_id: null,
		handlers: null
	}, a || {});

	if (localStorage.getItem('analytics'+a.customer_id) && JSON.parse(localStorage.getItem('analytics'+a.customer_id)).when > new Date().getTime() - analytics_cache_time && (typeof a.force_download == "undefined" || a.force_download !== true)){
		a.handlers.ok(JSON.parse(localStorage.getItem('analytics'+a.customer_id)).details);
	}else{
		var account = qms_tellerapp.team_enabled ? qms_tellerapp.account_key : "";
		var protocol = qms_tellerapp.protocol || document.location.protocol;
		var domain = qms_tellerapp.domain ? qms_tellerapp.domain : document.location.hostname;
		var port = qms_tellerapp.port;

		a.url = protocol + "://" + domain + ((port && port !== "") ? (":" + port) : "") + "/api/";
		a.account_key = account;
		if (!a.success || !a.error) {
			a.handlers = a.handlers || {};
		}

		if (a.callback) {
			a.handlers.finish = a.callback;
			delete a.callback;
		}


		//override the existing handler
		var ok_completed = a.handlers.ok;
		a.handlers.ok = function(response){
			response.customer_profile._refreshed_on = new Date().getTime();
			localStorage.setItem('analytics'+a.customer_id, JSON.stringify({details: response, when: new Date().getTime()}));
			ok_completed(response);
		};

		E.qms.api(a);
	}
}

function logout() {
	login({ logout: 1 }).finally(function () {
		if (websocket_channel) {
			websocket_channel.close();
			websocket_channel = null;
		}

		if (websocket_channel_polling_fallback) {
			websocket_channel_polling_fallback.close();
			websocket_channel_polling_fallback = null;
		}
	})
		}

function login(a) {
	if (a.callback) {
		var callback = a.callback;
		delete a.callback;
	}

	var login = {
		promisify: true,
		action: "login",
		account_key: a.subdomain,
		username: a.username,
		url: get_host(a) + "/api/",
		handlers: a.handlers || {}
	};

	if (a.logout) {
		login.logout = 1;
	}

	return api(login).then(function (response) {
		if (response && response.status === "login") {
			if (!login.logout) {
				var challenge_response = BL.crypto_sha1_paj.hex_hmac_sha1(
					BL.crypto_sha1_paj.hex_hmac_sha1(a.password, response.salt + login.username),
					response.challenge
				);

				return api({
					promisify: true,
					url: login.url,
					action: "login",
					account_key: login.account_key,
					login_username: login.username,
					login_challenge: response.challenge,
					login_response: challenge_response,
					login_login: "Login"
				});
			}
		}
	}).then(function (response) {
		if (response && response.status === "ok") {
			qms_tellerapp.account_key = login.account_key;
			qms_tellerapp.autologin = a.autologin;
			auth_data.username = login.username;
			auth_data.password = a.password;
			auth_data.token = response.token;

			if (a.autologin === "on") {
				qms_tellerapp.auth_data = auth_data;
			}
			localStorage.setItem('app-data', JSON.stringify(qms_tellerapp));
			console.log ("Logged in.");

			register_for_push();

			if (typeof callback == 'function') // TODO what is this?
                callback();

			return true;
		} else {
			localStorage.removeItem("app-data");
			qms_tellerapp.auth_data = auth_data = {};
			if (!login.logout){
				return false;
			}
		}
	});
}

function get_report(a) {
	a = BL.list.mergeinplace({
		report_id: null,
		dt_start: null,
		dt_end: null
	}, a || {});

	return api({
		promisify: true,
		action: "recent_activity", // TODO bad to pretend this is a generic fn when a single action
		format: "json",
		device_tz: new Date().getTimezoneOffset()
	}).then(function(response) {
		if (response.data.length > 0) {
			if (!qms_tellerapp.report) {
				qms_tellerapp.report = {};
			}

			qms_tellerapp.report['report-' + a.report_id] = response;
		}
	});
}

function get_recent_group_activity() {
	return get_report({ report_id: 51 });
}

function clean_localstorage_analytics(leadlist){
	var to_keep = {};
	for (var i=0; i < leadlist.length; i++){
		to_keep["analytics"+leadlist[i]["payload"]["customer_id"]] = 1;
	}

	for (key in localStorage){
		if ( localStorage.hasOwnProperty(key) && key.substr(0,9)=="analytics" && to_keep[key] != 1 ){
			localStorage.removeItem(key);
		}
	}
}

function get_ticket_list(a) {
	a = BL.list.mergeinplace({
		action: "lead_list",
		user_only: 1,
		queue_services: 1,
		properties: "payload,status,queue_id,seq,active_when",
		type: "current"
	}, a || {});

	return api(a).then(function(response) {
		if (response.queue_services) {
			qms_tellerapp.queue_services = response.queue_services;
		}

		leads.waiting = response.leads_waiting;
		leads.saved = [];

		if (response.ticket_list && response.ticket_list.length > 0) {
			clean_localstorage_analytics(response.ticket_list);
			
			return Promise.map(response.ticket_list, function (ticket) {
				return new Promise(function(resolve, reject) {
					analytics({
						customer_id: ticket.payload.customer_id,
						handlers: {
							ok: function (response) {
								ticket.customer_profile = response.customer_profile;
								resolve(ticket);
							},
							not_ok: function (error) {
								//reject(error);
								ticket.customer_profile = {leads_raised:"?",behaviour:{visits:"?"}, system:{}, location:{}, pages:[], last_seen:{secs_ago:1}, most_active:{}, timeline:[]}; //TODO better analytics failure handling
								resolve(ticket);
							}
						}
					})
				});
			}).map(function (ticket) {
				if (ticket.service_id == qms_tellerapp.queue_services[qms_tellerapp.teller.private_user_queue][0]) {
					leads.saved.push(ticket);
				} /*else {
					var found = false;
					leads.waiting.forEach(function(lead) {  //TODO  <------ this is a duplicate ticket filter, why would duplicate tickets exist?
						if (lead.id === ticket.id) {
							found = true;
						}
					});
					if (!found) {
						leads.waiting.push(ticket);
					}
				}*/
				return ticket;
			}).then(function(tickets) {
				set_state({ "leads": leads }, true);
				return tickets;
			});
		}

		return Promise.resolve();
	});
}

function get_teller_profile() {	// TODO no error handling
	var a = {
		action: "user_current_state",
		queue_lengths: 1,
		promisify: true
	};

	return api(a).then(function(response) {
		if (response && response.status === "ok") {
			qms_tellerapp.teller = response;
			for (var i = 0; i < response.teller_queues.length; i++) {
				if (response.teller_queues[i].config && response.teller_queues[i].config.private_user_queue) {
					qms_tellerapp.teller.private_user_queue = response.teller_queues[i].id; // TODO this should be qms_tellerapp.teller.private_queue_id
				}
			}

			return get_ticket_list({ promisify: true }).then(function () { // TODO this is a repeat of what is done in screens.show.leadslist() show()
				update_lead_notification();
			});
		} else {
			throw new Error("Unable to get teller profile");
		}
	}).then(function() {
		get_recent_group_activity();

		if (qms_tellerapp.teller.ticket_list &&
			qms_tellerapp.teller.ticket_list.length > 0){
			//this means that user_current_state (QMS: teller_current_state) has returned an array of tickets in processing
			//a processing ticket state means that this user has an active lead that they need to handle
			//this will be the first ticket at the top of the pile
			screens.show.leaddetails(null, {waiting_lead: qms_tellerapp.teller.ticket_list[0]});

		} else {
			screens.show.leadslist();
		}
	}).then(function() {
		if (!websocket_channel) {
			websocket_channel = new E.Websocket_channel({
				channel_id: qms_tellerapp.teller.websocket_channel_id,
				cluster: 'ap1',
				listen: false,
				auth_params: {
					account_key: qms_tellerapp.account_key,
					action: "ws_auth",
					token: auth_data.token
				},
				implementation: E.settings.websocket
			});

			if (!websocket_channel_polling_fallback) {
				websocket_channel_polling_fallback = new E.Websocket_channel_polling_fallback({
					websocket_channel: websocket_channel,
					activity_timeout_ms: 10000,
					polling_interval_ms: 1000 * 30,
					polling_state_hook: function (onoff) {
						network_indicator.state(onoff ? "missing" : "neutral");
					},
					polling_fn: function (a) {
//						if (websocket_channel.pusher.connection.state != "connected"){
						api({
							promisify: true,
							action: "user_polling"
						}).then(function(response) {
							if (response.events) {
								for (var i = 0, ii = response.events.length; i < ii; i++) {
									var event = response.events[i].event;
									if (a.handlers[event]) {
										for (var j = 0, jj = a.handlers[event].length; j < jj; j++) {
											a.handlers[event][j].call(null, response.events[i].data);
										}
									}
								}
							}
							//this might be when polling has stopped, and in fact complete after polling_state_hook has run, so do not want to undo that work.
							if (!network_indicator.statep("neutral")) {
								network_indicator.state("missing");
							}
							a.polling_callback();
						}).catch(function() {
							network_indicator.flash_additional_state("bad");
							a.polling_callback();
						});

						this.call_count = (this.call_count || 0) + 1;
						//note that on a final reconnection call this may not execute
						if (this.call_count % 7 === 0) {
							get_ticket_list({ promisify: true }).then(function () {
								update_lead_notification();
							});
						}
					}
//					}
				});
			}
			websocket_channel.addhandler("connection/connected", function () {
				network_indicator.state("neutral");
			});
			websocket_channel.addhandler("connection/disconnected", function () {
				network_indicator.state("missing");
			});
			websocket_channel.addhandler("queue-lengths", function (data) {
				get_ticket_list({ promisify: true }).then(function () {
					update_lead_notification();
				});
			});
			websocket_channel.addhandler("queue-stats", function (data) {
				var sum_waiting = 0;
				var queue_list = [];
				for (var i=0; i < data.length; i++){
					if (data[i]["id"] != qms_tellerapp.teller.private_user_queue && data[i]["length"] > 0){
						sum_waiting += data[i]["length"];
						queue_list.push(data[i]["id"]);
					}
				}
				leads.waiting = {number: sum_waiting,
								 queue_ids: queue_list};
				update_lead_notification();
			});

			return {"status": "ok"};
		}
	}).catch(function (error) {
		console.log(error.message);
	});
}

function update_lead_notification() { // TODO not pure. if this is only ever called after getting a new get_ticket_list() then add it into that fn, but maybe change to update_ticket_list()
    if (leads.waiting.number > 0) {
         // get the number from button and check new count is greater than old count. then olny raise notification.
        var old_lead_count = appbar_component.waiting_leads_button.content_el().innerHTML;
        if(old_lead_count < leads.waiting.number){
            $.notify("New message from lucep" + "\n" + "you have a new lead","info");
            $.playSound('../resources/common/sounds/level_up.mp3');
        }
        appbar_component.waiting_leads_button.content_el().innerHTML = leads.waiting.number;
        appbar_component.waiting_leads_count.classList.remove("is-hidden");
        
    } else {
        appbar_component.waiting_leads_count.classList.add("is-hidden");
    }
}

function format_to_readable_time (date) {

	var hours = date.getHours();
	var minutes = date.getMinutes();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	hours = hours % 12;
	hours = hours ? hours : 12; // the hour '0' should be '12'
	minutes = minutes < 10 ? '0' + minutes : minutes;

	return hours + ':' + minutes + ' ' + ampm;
}

function format_to_time_ago (last_seen_secs_ago){
	if (last_seen_secs_ago <= 60) {
		last_seen_text = "< 1 Min";
	} else if (last_seen_secs_ago <= 3600) {
		last_seen_text = Math.floor(last_seen_secs_ago / 60) % 60 +" Mins";
	} else if (last_seen_secs_ago <= 86400) {
		last_seen_text = Math.floor(last_seen_secs_ago / 3600) % 24 +" Hrs";
	} else {
		var days = Math.floor(last_seen_secs_ago / 86400);
		last_seen_text = (days > 1 ) ? days + " Days" : days+ " Day";
	}
	return last_seen_text;
}

function register_for_push (){
	var new_push_id = localStorage.getItem('push_reg_id');
	var push_registered = localStorage.getItem('push_reg_id_submitted');

	if (typeof device != 'undefined' && typeof new_push_id !='undefined' &&
		(typeof push_registered == "undefined" || push_registered == null || push_registered.id != new_push_id ||
		 push_registered.username != qms_tellerapp.auth_data.username ||
		 push_registered.account_key != qms_tellerapp.account_key)
	   ){
		if (device.platform == 'android' || device.platform == 'Android' || device.platform == 'amazon-fireos') {
			console.log ("REGISTERING GCM");
			app.register_with_lucep_gcm ({  reg_id: localStorage.getItem('push_reg_id'),
											auth: { name: qms_tellerapp.auth_data.username,
													account_key: qms_tellerapp.account_key },
											callback: function (resp){
												if (resp.status == true)
													localStorage.setItem('push_reg_id_submitted',
																		 JSON.stringify({id: new_push_id,
																		  username: qms_tellerapp.auth_data.username,
																		  account_key: qms_tellerapp.account_key}));
											}
										 });
		} else {
			console.log ("REGISTERING APN");
			app.register_with_lucep_apn ({  reg_id: localStorage.getItem('push_reg_id'),
											auth: { name: qms_tellerapp.auth_data.username,
													account_key: qms_tellerapp.account_key },
											callback: function (resp){
												if (resp.status == "ok")
													localStorage.setItem('push_reg_id_submitted',
																		 {id: new_push_id,
																		  username: qms_tellerapp.auth_data.username,
																		  account_key: qms_tellerapp.account_key});
											}
										 });
		}
	}else{
		console.log("Push ID already registered or not a valid device");
	}
}

var app = {
	start_push: function () {
		console.log("PUSH STARTED");
		
		if (typeof PushNotification != 'undefined'){
			var push = PushNotification.init({
				"android": {
					"senderID": push_data.gcm_sender_id
				},
				"ios": {	"sound": true,
							"vibration": true,
							"badge": true }
			});
			if (push) {
				push.on('registration', function (data) {
					console.log('Push successfully registered:', data.registrationId);
					console.log(JSON.stringify(data));

					localStorage.setItem('push_reg_id', data.registrationId);
				});

				push.on('notification', function (data) {
					console.log('notification event');
					console.log(JSON.stringify(data));

					//check if this is an update alert
					if (data.message == "An update is available"){
						navigator.notification.alert( data.message,
													  app.appupdate(data), // callback
													  data.title, // title
													  'Get Update' // buttonName
													);
					}else{
						if (leads.waiting.number < 1){
							get_ticket_list({promisify: true}).then(
								function(){
									update_lead_notification();
								}
							);
						}else{
							update_lead_notification();
						}

					}
					//var my_media = new Media("file:///android_asset/www/files/beep.wav");
					//my_media.play();
				});

				push.on('error', function (e) {
					console.log('GCM error', e);
				});
			} else {
				console.log ("Didnt getback a valid push object");
			}
		}
	},

	appupdate: function (a) {
		if (a.message === "An update is available") {
				if (device.platform == 'android' || device.platform == 'Android' || device.platform == 'amazon-fireos') {
					window.open('market://details?id=com.lucep.gorillateller', '_system', 'location=yes');
				} else {
					window.open('itms-apps://itunes.apple.com/app/id1037306948');

				}
		}

	},

	load_application_state: function() {
		if (localStorage.getItem("app-data")) {
			qms_tellerapp = BL.list.mergeinplace(JSON.parse(localStorage.getItem("app-data")) || {}, qms_tellerapp);
			auth_data = qms_tellerapp.auth_data || {};
		}
	},

	toast: function(message, position, offset) {
		window.plugins.toast.showWithOptions({
			message: message,
			duration: "long",
			position: typeof position != 'undefined' ? position : "bottom",
			addPixelsY: typeof offset != 'undefined' ? offset : -100
		});
	},

	initialize: function (a) {
		var self=this;
		$(document).ready(function () {
			if (typeof cordova != 'undefined'){
				document.addEventListener('deviceready', self.on_device_ready, false);
				document.addEventListener('backbutton', self.on_back_button, false);
			}else{
				console.log("Starting Lucep Web...");
				self.on_device_ready();
			}
		});		
	},

	on_back_button: function () {
		//exception case for new leads and tutorials
		if (!tutorial_overlay_component.el.classList.contains("is-hidden")){
			return; //prevent anything changing if in tutorial mode
		}
		if (leaddetails_component.el.classList.contains("new-lead")){
			appbar_component.context_actions_container.classList.toggle("is-hidden"); //show the menu bar instead of exiting
			return; //prevent backing out of the app if viewing a new lead
		}
		if (!lead_transfer_component.el.classList.contains("is-hidden")){
			//the lead transfer dialog is active, dismiss it
			lead_transfer_component.hide();
			return;
		}

		//something is wrong, get out of the app in this circumstance
		if (typeof screens == "undefined" || typeof screens.current_id != "function")
			navigator.app.exitApp();

		switch (screens.current_id()){
			//screens where the back button should work
		case "licenselimits":
		case "leaddetails":
		case "groupactivity":
			screens.show.leadslist();
			break;
			//screens where it should do nothing
		case "loader_overlay":
		case "tutorial-overlay":

			break;
			//by default, exit the app
		case "login":
		default:
			navigator.app.exitApp();
			break;

		}
	},

	register_with_lucep_gcm : function(details){
        var self = this;
		$.get(  push_data.push_server+"api/",
                { action: "register_gcm",
                  deviceid: details.reg_id,
                  unique_id: details.auth.name,
                  account_key: details.auth.account_key },
                function (resp){
					if (typeof details.callback == 'function')
						details.callback(resp);
                    console.log(JSON.stringify(resp));
                }, "json");
    },

	register_with_lucep_apn : function(details){
        var self = this;
		$.post(	push_data.push_server+"api/",
				{	action: "register_apple",
					task: "register",
					appname: details.auth.account_key,
					appversion: 1,
					deviceuid: details.auth.name,
					devicetoken:  details.reg_id,
					devicename: details.auth.name,
					devicemodel: 1.9,
					deviceversion: "1",
					pushbadge: "enabled",
					pushalert: "enabled",
					pushsound: "enabled" },
					function (resp){
						console.log("APN response:");
						console.log(JSON.stringify(resp));

						if (typeof details.callback == 'function')
							details.callback(resp);

					   }, "json");
		return true;
    },

	on_device_ready: function () {
		// TODO move post user state retrieval
		if (typeof device != 'undefined')
			window.open=cordova.InAppBrowser.open;

		//Handle Android specific box-shadow rendering workaround for the tutorial overlay
		if (typeof device != 'undefined' && (device.platform == 'android' || device.platform == 'Android' || device.platform == 'amazon-fireos')){
			var css = '#tutorial-highlight{ -moz-box-shadow: 0 0 0px 9000px rgba(0,0,0,0.7); -webkit-box-shadow: 0 0 0px 9000px rgba(0,0,0,0.7); box-shadow: 0 0 0px 9000px rgba(0,0,0,0.7); }';
			var head = document.getElementsByTagName('head')[0];
			var s = document.createElement('style');
			s.setAttribute('type', 'text/css');
			if (s.styleSheet) {   // IE
				s.styleSheet.cssText = css;
			} else {                // the world
				s.appendChild(document.createTextNode(css));
			}
			head.appendChild(s);
		}

		app.load_application_state();
		app.start_push();
		//=================================================================================================
		screens = new E.Screens({
			reshow_as_show: false,

			after_load_hook: function (show_screen) { // TODO the arg will contain any passes user data, what is "show_screen"?
				if (window.navigator.splashscreen) {
					window.navigator.splashscreen.hide();
				}

				if (!auth_data || !auth_data.token) {
					document.getElementById("loading").classList.add("is-hidden");
					screens.show.login();
				} else {
					get_teller_profile().then(function (resp){
						if (typeof resp != "undefined" || document.body.classList.contains("screen-login")){
							document.getElementById("loading").classList.add("is-hidden");

							if (typeof resp != "undefined")
								register_for_push();

						}else
							document.getElementById("loading").classList.add("offline");
					});
				}
			}
		});

		screens.add_hook('show_screenbox', 'after', function (returning, args /* (id, args, comblock_args) */) {
			var self = this;
			this.screenbox_ids().map(function (id) {
				var tab = document.getElementById("tabbar-" + id + "-button");
				if (tab) {
					if (id === self.current_id()) {
						tab.classList.add("current");

						// set the dark bg height based on the current tab height
						var bg_screen = document.getElementById("background-screen");
						bg_screen.classList.remove("is-hidden");
						if (bg_screen.offsetHeight <= document.getElementById(id).offsetHeight) {
							document.getElementById("background-screen").style.height = document.getElementById(id).offsetHeight + "px";
						} else if (bg_screen.offsetHeight > document.getElementById(id).offsetHeight) {
							document.getElementById("background-screen").style.height = "100%";
						}
					} else {
						tab.classList.remove("current");
					}
				}

				// reset scroll
				document.body.scrollTop = 0;
			});

		});
		screens.add_hook('add_screenbox', 'after', function (returning, args /* (id, realp) */) {
			var screen_id = args[0];
			var screen = tabs[screen_id];
			var el = document.getElementById("tabbar");

			if (!el) return;

			var temp = document.createElement("ul");
			if (screen_id != "login" && screen && !screen.no_tab) {
				temp.innerHTML =
					"<div id='tabbar-" + screen_id + "-button' class='tabbar-button menu-item'>" +
					"<i class='tabbar-button-icon " + screen["tabbar_icon_class"] + "'></i>" +
					"</div>";
				el.appendChild(temp.firstChild);
				var self = this;
				document.getElementById("tabbar-" + screen_id + "-button").onclick = function () {
					self.show[screen_id]();
				};
			}
		});

		//=================================================================================================
		network_indicator = new E.Simple_indicator();

		//=================================================================================================
		login_component = {
			el: BL.container_el("login", "login is-hidden"),
			show: function (a) {
				document.getElementById("background-screen").classList.add("is-hidden");
				// TODO this should almost all be in load
				this.el.innerHTML =
					"<div class='app-login-container'>" +
					"<div class='logo'></div>" +
					"<div class='login-container'>" +
					"<div class='login-title'>" + E.lt("login-title") + "</div>" +
					"<div id='login-form-container' class='login-form-container'></div>" +
					"</div>" +
					"<div class='login-actions-container'>" +
					"<input id='auto-login' checked='checked' class='auto-login is-hidden' />" +
					"<div id='login-button-container' class='login-button-container'></div>" +
					"<div id='forgot-password' class='forgot-password'>" + E.lt("forgot-credentials") + "</div>" +
					"</div>" +
					"</div>";

				var login_form_team_ml =
					"<div class='login-form-element'>" +
					"<label class='login-form-label'>" + E.lt("team") + "</label>" +
					"<div class='login-form-input-container'>" +
					"<div class='login-form-element-icon'><i class='icon-mobile'></i></div>" +
					"<input class='login-form-input' id='login-team' placeholder='" + E.lt("team") + "' />" +
					"</div>" +
					"</div>";

				var login_form_ml =
					"<div class='login-form-element'>" +
					"<label class='login-form-label'>" + E.lt("username") + "</label>" +
					"<div class='login-form-input-container'>" +
					"<div class='login-form-element-icon'><i class='icon-user'></i></div>" +
					"<input class='login-form-input' id='login-username' placeholder='" + E.lt("username") + "' />" +
					"</div>" +
					"</div>" +
					"<div class='login-form-element'>" +
					"<label class='login-form-label'>" + E.lt("password") + "</label>" +
					"<div class='login-form-input-container'>" +
					"<div class='login-form-element-icon'><i class='icon-lock'></i></div>" +
					"<input class='login-form-input' id='login-password' type='password' placeholder='" + E.lt("password") + "' />" +
					"</div>" +
					"</div>";

				var login_ml = qms_tellerapp && qms_tellerapp.team_enabled ? login_form_team_ml + login_form_ml : login_form_ml;

				if (a.error) {
					login_ml += "<div class='error'>" + E.lt("login-error") + "</div>";
				}

				document.getElementById('login-form-container').innerHTML =  login_ml;
				document.getElementById('forgot-password').addEventListener("click", function (f){
					window.open("https://lucep.com/set-password", '_system');
				});

				var login_btn = this.login_btn = new BL.el.Button({
					id: "login-button",
					text: E.lt("login"),
					classes: "button login-button action-button",
					place: "login-button-container",
					click: function () {
						document.getElementById("login-button-content").style.visibility = "hidden";
						login_btn.el().classList.add("loading"); // TODO should be able to just use "this"
						login_btn.el().classList.add("animated");

						var subdomain_el = document.getElementById("login-team");
						var username_el = document.getElementById("login-username");
						var password_el = document.getElementById("login-password");
						var autologin_el = document.getElementById("auto-login");

						subdomain_el.disabled = "disabled";
						username_el.disabled = "disabled";
						password_el.disabled = "disabled";
						autologin_el.disabled = "disabled";

						var subdomain = subdomain_el.value;
						var username = username_el.value;
						var password = password_el.value;
						var autologin = autologin_el.value;

						subdomain = subdomain ? subdomain.toLowerCase() : "";
						username = username ? username.toLowerCase() : "";

						var a = {
							subdomain: subdomain,
							username: username,
							password: password,
							autologin: autologin || "on"
						};

						login(a).then(function (login_result) {
							if (login_result){
								return get_teller_profile();
							}else{
								alert("Your login credentials were not valid. Please try again!"); //TODO make this with a nicer UI

								document.getElementById("login-button-content").style.visibility = "visible";
								login_btn.el().classList.remove("loading"); // TODO should be able to just use "this"
								login_btn.el().classList.remove("animated");

								var subdomain_el = document.getElementById("login-team");
								var username_el = document.getElementById("login-username");
								var password_el = document.getElementById("login-password");
								var autologin_el = document.getElementById("auto-login");

								subdomain_el.removeAttribute("disabled");
								username_el.removeAttribute("disabled");
								password_el.removeAttribute("disabled");
								autologin_el.removeAttribute("disabled");
							}
						} );
					}
				});
				this.login_btn.state("normal");

				this.el.classList.remove("is-hidden");
			},

			reshow: function () {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function () {
			},

			load: function (a) {
				return true;
			}
		};

		//=================================================================================================
		appbar_component = {
			el: BL.container_el("appbar", "appbar is-hidden"),
			show: function (a) {
				a = BL.list.mergeinplace({
					context_actions: [],
					context_button_icon_class: null
				}, a || {});

				if (a.context_button_icon_class && a.context_actions) {
					// reset app menu container for the new contextual action
					this.app_menu_container.innerHTML = "";

					// arrow
					var arrow = document.createElement("span");
					arrow.classList.add("arrow");

					// create the context actions div to hold the list of actions
					this.context_actions_container = document.createElement("div");
					this.context_actions_container.id = "contextual-actions-container";
					this.context_actions_container.classList.add("contextual-actions-container", "is-hidden");
					this.context_actions_container.appendChild(arrow);

					this.app_menu_container.appendChild(this.context_actions_container);

					a.context_actions.forEach(function (action) {
						var div = document.createElement("div");
						div.id = action.button_props.id + "-container";
						appbar_component.context_actions_container.appendChild(div);
						new BL.el.Button({
							id: action.button_props.id,
							text: action.button_props.text,
							classes: "transparent-button " + action.button_props.icon_class,
							attrs: action.button_props.attrs,
							click: function (e) {
								action.button_action(e);
							},
							place: div
						});
					});

					new BL.el.Button({
						id: "context-menu-button",
						classes: "context-menu-button transparent-button app-bar-button " + a.context_button_icon_class,
						place: this.app_menu_container,
						click: function () {
							appbar_component.context_actions_container.classList.toggle("is-hidden");
						}
					});
				}

				if (this.loaded) {
					this.el.classList.remove("is-hidden");
				}
			},

			reshow: function (a) {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
				// update_lead_notification();

			},

			load: function (a) {		// TODO ?! so the first time it is called it loads but does not show, then the next time it does not load and shows?
				if (!this.loaded) {
					this.el.innerHTML =
						"<div id='back-button-container' class='back-button-container appbar-item'></div>" +
						"<div class='logo appbar-item'></div>" +
						"<div id='app-menu-container' class='app-menu-container appbar-item'></div>" +
						"<div id='waiting-leads-count' class='waiting-leads-count appbar-item is-hidden'>" +
						"<div id='waiting-leads-overlay' class='waiting-leads-overlay'></div>" +
						"</div>";

					this.back_button = new BL.el.Button({
						id: "back-button",
						classes: "back-button transparent-button icon-left-big app-bar-button",
						text: "",
						place: "back-button-container",
						click: function () {
							screens.show.leadslist();
						}
					});

					this.waiting_leads_button = new BL.el.Button({
						id: "waiting-leads-button",
						place: "waiting-leads-count",
						classes: "waiting-leads-button transparent-button app-bar-button animated infinite slow flash pulse",
						click: function () {
							if (! leaddetails_component.el.classList.contains("new-lead"))
								new_lead_notification_component.load(); // TODO this is not load, but show
						}
					});

					this.app_menu_container = document.getElementById("app-menu-container");

					document.body.onmouseup = function (e) {
						if (!document.getElementById("app-menu-container").contains(e.target)) { // TODO why not just attach to the div?
							if (appbar_component.context_actions_container) {
								appbar_component.context_actions_container.classList.add("is-hidden");
							}
						}
					};
				}
				this.waiting_leads_count = document.getElementById("waiting-leads-count");

				if (a && this.loaded) {
					this.show(a)
				}

				this.loaded = true;
				return true;
			}
		};

		//=================================================================================================
		tabbar_component = {
			el: BL.container_el("tabbar", "tabbar is-hidden"),
			show: function () {
				this.el.classList.remove("is-hidden");
			},
			reshow: function () {
			},
			hide: function () {
				this.el.classList.add("is-hidden");
			},
			before_show_hook: function (a) {
			},
			load: function (a) {
				return true;
			}
		};

		//=================================================================================================
		licenselimits_component = {
			el: BL.container_el("licenselimits", "screen is-hidden"),
			show: function (a){
				this.el.innerHTML = "<div class='no-license'><div class='license-info'><span class='headline'>"+a.headline+"</span><span class='explain'>"+a.explain+"</span><span class='ps'>"+a.ps+"</span><div id='upgrade-now'>Yes! Upgrade me now!</div><div id='upgrade-later'>No thanks. I don't need this lead right now.</div></div></div>";
				this.el.classList.remove("is-hidden");
				document.getElementById("upgrade-now").addEventListener("click", function(){
					window.open("https://lucep.com/login");
				});
				document.getElementById("upgrade-later").addEventListener("click", function(){
					screens.show.leadslist();
				});
			},
			hide: function (a){
				this.el.classList.add("is-hidden");
			}
		};
		//=================================================================================================
		leadslist_component = {
			el: BL.container_el("leadslist", "screen is-hidden"),
			show: function (a) {
				var self = this;

				if (a.hard_reload || !leads || !(leads.saved && leads.saved.length > 0)) { // TODO why this test? and is there a spinner before this big action? is this wrong? if you have no saved but waiting it shows nothing? (KV: modified to remove test for leads waiting)
					get_ticket_list({ promisify: true }).then(function() {
						if (!qms_tellerapp.teller.private_user_queue) {
							self.el.innerHTML = "<div class='no-leads'>You don't seem to have a Private Queue. Please check with your administrator.</div>"; // TODO why wait for reply for this?
						} else if (leads.saved.length == 0) {
							self.el.innerHTML = "<div class='no-leads'>You have not saved any Leads yet</div>";
						} else {
							saved_leads.clear();
							for (var i = 0; i < leads.saved.length; i++) {
								saved_leads.add(leads.saved[i]);
							}
						}
					}).then(function () {
						update_lead_notification();
					});
				} else {
					saved_leads.clear();
					for (var i = 0; i < leads.saved.length; i++) {
						saved_leads.add(leads.saved[i]);
					}
				}

				self.el.classList.remove("is-hidden");
			},
			reshow: function () {
			},
			hide: function () {
				this.el.classList.add("is-hidden");
			},

			after_show_hook: function (){
				if (! leaddetails_component.el.classList.contains("new-lead") && leads.waiting.number > 0)
					new_lead_notification_component.load(); // TODO this is not load, but show
			},

			before_show_hook: function (a) {
				appbar_component.load({	// TODO this is a show () (and why in before show? violates usage pattern) because it is not the first call (which was when loading the screens). it is also in the leadslist screen, and the leadslist screen show will call appbar_component.show() again but without any args not much happens except unhide. this will receive screen meta when it is reshown so it can customize itself.
					context_button_icon_class: "icon-user",
					context_actions: [{
						button_props: {
							id: "logout-button",
							icon_class: "icon-logout",
							text: E.lt("logout")
						},
						button_action: function (e) {
							logout();
						}
					}]
				});

				appbar_component.back_button.state("hidden");
			},

			load: function (a) {
				return true;
			}
		};

		saved_leads = new E.Elist({
			id_prefix: "saved-lead",
			container_elem: leadslist_component.el,
			add_item_timestamp: true,
			make_item_ml: function (item) {
				var lead_name = item.payload && item.payload.name ? item.payload.name : item.ticket_number;
				return (
					"<div id='" + item._mlid() + "' class='saved-leads'>" +
						"<div id='" + item._mlid("saved-lead-container") + "' class='saved-lead' data-ticket-id='" + item.id + "'>" +
						"<div class='avatar-container saved-lead-item'>" +
						"<div id='" + item._mlid("saved-lead-avatar") + "' class='avatar'></div>" +
						"</div>" +
						"<div class='saved-lead-info saved-lead-item'>" +
						"<div id='" + item._mlid("saved-lead-name") + "' class='saved-lead-name'>" +
						"<span class='name'>" + lead_name + "</span>" +
						"</div>" +
						"</div>" +
						"<div id='" + item._mlid("saved-lead-comm-menu") + "' class='saved-lead-comm-menu saved-lead-item'></div>" +
						"</div>" +
						"<div id='" + item._mlid("saved-lead-notes-container") + "' class='saved-lead-notes-container'></div>" +
						"</div>"
				);
			},

			prepare: function (item) {
				var phone_number;
				if (item.phone_number) {
					phone_number = item.phone_number;
				} else if (item.payload && item.payload.phone_number) {
					phone_number = item.payload.phone_number;
				}

				if (phone_number) {
					new BL.el.Button({
						id: item._mlid("lead-call"),
						text: "",
						classes: "saved-lead-comm-button transparent-button icon-phone",
						place: item._mlid("saved-lead-comm-menu"),
						click: function (a) {
							window.open('tel:'+phone_number, '_system', 'location=yes');
						}
					});
					new BL.el.Button({
						id: item._mlid("lead-sms"),
						text: "",
						classes: "saved-lead-comm-button transparent-button icon-chat-empty",
						place: item._mlid("saved-lead-comm-menu"),
						click: function (a) {
							window.open('sms:'+phone_number, '_system', 'location=yes');
						}
					});
				}

				var notes = (item.payload && item.payload.lead_notes) ? item.payload.lead_notes : "";
				if (notes) {
					document.getElementById(item._mlid("saved-lead-notes-container")).innerHTML =
						"<div id='" + item._mlid("lead-notes") + "' class='saved-lead-notes'>" +
						"<div class='lead-notes-value'>" + notes + "</div>" +
						"</div>";
				} else {
					document.getElementById(item._mlid("saved-lead-notes-container")).innerHTML =
						"Customer raised request for <strong>" + item["payload"]["service"] + "</strong> on <strong>" + item["active_when"] + "</strong>\n" +
						"This is their <strong>" + get_ordinal(item["customer_profile"]["behaviour"]["visits"]) +"</strong> visit to the website and was referred from " + item["customer_profile"]["behaviour"]["referrer"];
				}

				document.getElementById(item._mlid("saved-lead-container")).addEventListener('click', function (e) {
					if (this.contains(e.target)) {
						var ticket_id = e.currentTarget.getAttribute("data-ticket-id");
						screens.show.leaddetails(null, { saved_lead: saved_leads.id_find({ id: parseInt(ticket_id) }) });
					}
				});
			}
		});

		//=================================================================================================
		leaddetails_component = {
			el: BL.container_el("leaddetails", "screen is-hidden"), // TODO this is not a 'screen'! it is a part of one.
			show: function (a) {
				var thi = this;
				if (a) {
					var ticket = a.saved_lead || a.waiting_lead;

					analytics({customer_id: ticket.payload.customer_id,
							   force_download: typeof a.waiting_lead != 'undefined',
							   handlers:{
								   ok: function (response) {
									   ticket.customer_profile = response.customer_profile;
									   thi.draw_lead(ticket);
								   },
								   not_ok: function (error) {
									   //return false; //TODO error handling
									   ticket.customer_profile = {leads_raised:"?",behaviour:{visits:"?"}, system:{}, location:{}, pages:[], last_seen:{secs_ago:1}, most_active:{}, timeline:[]}; //TODO better analytics error handling
									   thi.draw_lead(ticket);
								   }
							   }
							  });
				}
			},
			draw_lead: function (lead){
				var name, phone_number, notes, location, requested_service;
				var entityMap = {
					'&': '&amp;',
					'<': '&lt;',
					'>': '&gt;',
					'"': '&quot;',
					"'": '&#39;',
					'/': '&#x2F;',
					'`': '&#x60;',
					'=': '&#x3D;'
				};
				
				var escapeHtml = function (string) {
					return String(string).replace(/[&<>"'`=\/]/g, function (s) {
						return entityMap[s];
					});
				}
				
				if (lead) {
					name = lead.payload && lead.payload.name ? lead.payload.name : lead.ticket_number;
					if (lead.phone_number) {
						phone_number = lead.phone_number;
					} else if (lead.payload && lead.payload.phone_number) {
						phone_number = lead.payload.phone_number;
					}
					notes = lead.payload ? lead.payload.lead_notes : "";
					location = typeof lead.location != 'undefined' ? lead.location : (typeof lead.payload.geotext != 'undefined' ? lead.payload.geotext : (typeof lead.payload.location != 'undefined' ? lead.payload.location : 'Unknown'));
					requested_service = lead.payload.service;
				}
				document.getElementById("viewing_lead_id").value = lead.id;
				document.getElementById("lead-detail-name").innerHTML = name;
				document.getElementById("lead-detail-name-simple").innerHTML = name;
				document.getElementById("lead-detail-location").innerHTML = location + " <div id='lead-location-container' class='lead-location-container'></div>";
				//get some basic information about the phone number, and format it for display
				if (lead.payload && lead.payload.phone_number)
					var formats = $lucep_country_lookup.get_country_area_from_number(lead.payload.phone_number.substring(1));
				if (!formats)
					formats = {country_code: null,
							   area_name: null};
				var type_descr;
				var type_code = formats ? intlTelInputUtils.getNumberType(lead.payload.phone_number, "+"+formats.country_code) : -1 ;
				switch(type_code){
				case 0:
					type_descr = "fixed line";
					break;
				case 1:
					type_descr = "mobile";
					break;
				case 2:
					type_descr = "fixed line, or mobile";
					break;
				case 3:
					type_descr = "toll free";
					break;
				case 4:
					type_descr = "premium rate";
					break;
				case 5:
					type_descr = "shared cost";
					break;
				case 6:
					type_descr = "VOIP";
					break;
				case 7:
					type_descr = "personal";
					break;
				case 8:
					type_descr = "pager";
					break;
				case 9:
					type_descr = "universal access";
					break;
				case 10:
					type_descr = "voicemail";
					break;
				case -1:
					type_descr = false;
					break;
				}
				document.getElementById("lead-detail-contact-telephone").innerHTML = intlTelInputUtils.formatNumber(lead.payload.phone_number, "+"+formats.country_code, 1);
				document.getElementById("lead-detail-contact-telephone-stats").innerHTML = (formats.area_name ? formats.area_name+", " : "") + (formats.country_name ? formats.country_name + " - " : "") + (type_descr ? "most likely a "+type_descr+" number" : "however, the type of number is uncertain");

				if (lead.payload && lead.payload.email)
					document.getElementById("lead-detail-number-info-email-pane").innerHTML = '<div class="icon-mail item"></div><div class="page-detail item"><div id="lead-detail-contact-telephone" class="page-title">'+ escapeHtml(lead.payload.email) +'</div></div>';
				else
					document.getElementById("lead-detail-number-info-email-pane").innerHTML = '';
				
				document.getElementById("lead-detail-company").innerHTML = "";
				document.getElementById("lead-detail-service").innerHTML = lead.payload.service;
				document.getElementById("lead-notes-input").value = notes || "";

				if (location) {
					new BL.el.Button({
						id: "lead-location-action-open",
						text: "",
						classes: "icon-location transparent-button",
						place: "lead-location-container",
						click: function (a) {
							window.open("geo:0,0?q=" + location, '_system');
						}
					});
				}

				//clear contact action container as new elements will be inserted there
				document.getElementById("contact-action-sms-container").innerHTML = "";
				document.getElementById("contact-action-call-container").innerHTML = "";
				document.getElementById("contact-action-skype-container").innerHTML = "";

				if (phone_number) {

					new BL.el.Button({
						id: "lead-contact-sms",
						text: "",
						classes: "icon-chat-empty transparent-button contact-action-button",
						place: "contact-action-sms-container",
						click: function (a) {
							window.open('sms:'+phone_number, '_system', 'location=yes');
						}
					});

					new BL.el.Button({
						id: "lead-contact-call",
						text: "",
						classes: "icon-phone transparent-button contact-action-button",
						place: "contact-action-call-container",
						click: function (a) {
							window.open('tel:'+phone_number, '_system', 'location=yes');
						}
					});

					new BL.el.Button({
						id: "lead-contact-skype",
						text: "",
						classes: "icon-skype transparent-button contact-action-button",
						place: "contact-action-skype-container",
						click: function (a) {
							console.log("Skype button "+ phone_number);
							window.open('skype:'+phone_number+'?call', '_system', 'location=yes');

							/*startApp.set({
							  "action": "ACTION_VIEW",
							  "uri": "skype:" + phone_number
							  }).start();*/
						}
					});

					/*new BL.el.Button({
					  id: "contact-actions-more",
					  text: "",
					  classes: "icon-ellipsis-vert contact-actions-more-button",
					  place: "contact-actions-more-overflow-container",
					  click: function (a) {
					  // Works but saves to contact directly instead of offering edit. Maybe create -> get id -> edit id?
					  navigator.contacts.create({
					  displayName: name,
					  phoneNumbers: [new ContactField('mobile', phone_number, true)],
					  note: notes
					  }).save(
					  function (success) {
					  app.toast("Contact saved!", null, null);
					  console.log('Successfully saved contact', success);
					  },
					  function (err) {
					  app.toast("Unable to save contact - try again?", null, null);
					  console.log('Error saving contact', err);
					  }
					  );
					  }
					  });*/
				}

				if (lead.active_when) {
					var validdate = lead.active_when.split(" ")[0]+"T"+lead.active_when.split(" ")[1];
					var active_when = new Date(validdate);
					document.getElementById("lead-detail-datetime-claimed").innerHTML = active_when.getDate() + " " + active_when.getMonthNameShort() + ", " + active_when.getFullYear();
				}

				var analytics_ago = (new Date().getTime() - lead.customer_profile._refreshed_on)/1000;
				document.getElementById("lead-detail-datetime-analytics").innerHTML = format_to_time_ago(analytics_ago) +" ago"; //TODO - support i18n

				var lead_detail_header = document.getElementById("lead-detail-header");
				var lead_detail_header_simple = document.getElementById("lead-detail-header-simple");

				// Show/hide lead-detail mini header based on scroll
				var scroll_handler = on_visibility_change(lead_detail_header, function (visible) {
					if (!visible) {
						lead_detail_header_simple.classList.add("slideInDown");
						lead_detail_header_simple.classList.remove("is-hidden");
						setTimeout(function () {
							lead_detail_header_simple.classList.remove("slideInDown");
						}, 1000);
					} else {
						lead_detail_header_simple.classList.add("slideOutUp");
						setTimeout(function () {
							lead_detail_header_simple.classList.remove("slideOutUp");
							if (is_element_in_viewport(lead_detail_header)) {
								lead_detail_header_simple.classList.add("is-hidden");
							}
						}, 1000);
					}
				});
				addEventListener('scroll', scroll_handler, false);

				if (! document.getElementById("notes-expand").hasChildNodes()){
					var notes_container_toggle = function (e) {
						document.getElementById("lead-notes-input-container").classList.toggle("is-hidden");
						var notes_toggle_button = document.getElementById("lead-detail-notes-toggle-button");

						notes_toggle_button.classList.toggle("icon-down-open");
						notes_toggle_button.classList.toggle("icon-up-open");
					};
					var notes_input = document.getElementById("lead-notes-input");

					new BL.el.Button({
						id: "lead-detail-notes-toggle-button",
						text: "",
						classes: "notes-toggle-button transparent-button icon-down-open",
						place: "notes-expand",
						attrs: "data-ticket-id=" + lead.id,
						click: notes_container_toggle
					});
					document.getElementById("collapsed-notes-label").addEventListener("click", notes_container_toggle);

					var save_notes = function (e) {
						var notes = notes_input.value;
						if (lead.payload.notes !== notes) {
							save_notes_button.content_el().innerHTML = E.lt("saving");
							save_notes_button.state("processing");

							api({
								action: "lead_update",
								promisify: true,
								id: lead.id,
								lead_notes: notes
							}).then(function (response) {
								save_notes_button.content_el().innerHTML = E.lt("saved");
								save_notes_button.state("disabled");
								for (var i = 0; i < leads.saved.length; i++) {
									if (leads.saved[i].id === lead.id) {
										leads.saved[i].payload = leads.saved[i].payload || {};
										lead.payload.lead_notes = leads.saved[i].lead_notes = notes;
									}
								}
							}).catch(function (response) {
								var btn_bg = save_notes_button.el().style.background;

								save_notes_button.content_el().innerHTML = E.lt("error");
								save_notes_button.el().style.background = "#c33620";
								setTimeout(function () {
									save_notes_button.state("normal");
									save_notes_button.el().style.background = btn_bg;
									save_notes_button.content_el().innerHTML = E.lt("save");
								}, 1500);
							});
						}
					};

					var save_notes_button = new BL.el.Button({
						id: "lead-notes-save-button",
						classes: "notes-save-button action-button",
						place: "lead-notes-save-button-container",
						attrs: "data-ticket-id=" + lead.id,
						state: "disabled",
						click: save_notes
					});
					save_notes_button.content_el().innerHTML = E.lt("saved");
					save_notes_button.state("disabled");

					// document.body.onmouseup = function (e) {
					//   if (!document.getElementById("lead-notes-input").contains(e.target)) {
					//     save_notes();
					//   }
					// };

					notes_input.addEventListener("input", function(e) {
						save_notes_button.state("normal");
						save_notes_button.content_el().innerHTML = E.lt("save");
					});
				}
				document.getElementById("engagement-label-1").innerHTML = E.lt("site-visits-label");
				document.getElementById("engagement-label-2").innerHTML = E.lt("callbacks-label");
				document.getElementById("engagement-label-3").innerHTML = E.lt("last-touch-label");

				document.getElementById("engagement-metric-1").innerHTML = lead.customer_profile.behaviour.visits;
				document.getElementById("engagement-metric-2").innerHTML = lead.customer_profile.leads_raised;


				var last_seen_text, last_seen_secs_ago = parseInt(lead.customer_profile.last_seen.secs_ago, 10);
				document.getElementById("engagement-metric-3").innerHTML = format_to_time_ago(last_seen_secs_ago);

				// device summary
				// device type
				var lead_detail_device_type_icon_class = "icon-help";
				var lead_detail_device_type_icon_label = "Device";
				switch (lead.customer_profile.system["device-type"]) {
				case "Mobile":
				case "mobile":
				case "mob":
					lead_detail_device_type_icon_class = "icon-mobile";
					lead_detail_device_type_icon_label = "Mobile";
					break;

				case "Tablet":
				case "tablet":
				case "Mobile/Tablet":
				case "tab":
					lead_detail_device_type_icon_class = "icon-tablet";
					lead_detail_device_type_icon_label = "Tablet";
					break;

				case "Desktop":
				case "desktop":
					lead_detail_device_type_icon_class = "icon-desktop";
					lead_detail_device_type_icon_label = "Desktop";
					break;

				case "Laptop":
				case "laptop":
					lead_detail_device_type_icon_class = "icon-laptop";
					lead_detail_device_type_icon_label = "Laptop";
					break;
				}
				document.getElementById("lead-detail-device-type-icon").classList.add(lead_detail_device_type_icon_class);
				document.getElementById("lead-detail-device-type").innerHTML = lead_detail_device_type_icon_label;

				// device os
				var lead_detail_os_icon_class, lead_detail_os_icon_label;
				switch (lead.customer_profile.system["os"]) {
				case "Windows":
				case "windows":
				case "win":
				case "Win32":
					lead_detail_os_icon_class = "icon-windows";
					lead_detail_os_icon_label = "Windows";
					break;
				case "Mac":
				case "MacIntel":
					lead_detail_os_icon_class = "icon-apple";
					lead_detail_os_icon_label = "Mac";
					break;
				case "Linux":
				case "linux":
					lead_detail_os_icon_class = "icon-linux";
					lead_detail_os_icon_label = "Linux";
					break;
				case "tablet":
				case "tab":
					lead_detail_os_icon_class = "icon-tablet";
					lead_detail_os_icon_label = "Tablet";
					break;
				default:
					lead_detail_os_icon_class = "icon-help";
					lead_detail_os_icon_label = "Computer"

				}
				document.getElementById("lead-detail-os-icon").classList.add(lead_detail_os_icon_class);
				document.getElementById("lead-detail-os").innerHTML = lead_detail_os_icon_label;
				// browser
				var lead_detail_browser_icon_class, lead_detail_browser_icon_label;
				switch (lead.customer_profile.system["browser"]) {
				case "chrome":
				case "Chrome":
					lead_detail_browser_icon_class = "icon-chrome";
					lead_detail_browser_icon_label = "Chrome";
					break;
				case "Firefox":
				case "firefox":
					lead_detail_browser_icon_class = "icon-firefox";
					lead_detail_browser_icon_label = "Firefox";
					break;
				case "Opera":
				case "opera":
					lead_detail_browser_icon_class = "icon-opera";
					lead_detail_browser_icon_label = "Opera";
					break;
				case "Safari":
				case "safari":
					lead_detail_browser_icon_class = "icon-safari";
					lead_detail_browser_icon_label = "Safari";
					break;
				case "Amazon":
				case "amazon":
					lead_detail_browser_icon_class = "icon-amazon";
					lead_detail_browser_icon_label = "Amazon";
					break;
				case "ie":
				case "Internet Explorer":
				case "edge":
					lead_detail_browser_icon_class = "icon-internet-explorer";
					lead_detail_browser_icon_label = "Internet Explorer";
					break;
				default:
					lead_detail_browser_icon_class = "icon-help";
					lead_detail_browser_icon_label = "Generic Browser"

				}
				document.getElementById("lead-detail-browser-icon").classList.add(lead_detail_browser_icon_class);
				document.getElementById("lead-detail-browser").innerHTML = lead_detail_browser_icon_label;

				// Referrer
				var referrer_icon = "";
				switch(lead.customer_profile.behaviour["channel"]){
				case "Google ads":
					referrer_icon = "icon-google";
					break;
				case "Search engine":
					referrer_icon ="icon-search";
					break;
				case "Facebook":
					referrer_icon = "icon-facebook";
					break;
				case "Twitter":
					referrer_icon = "icon-twitter";
					break;
				case "Linked In":
					referrer_icon = "icon-linkedin";
					break;
				case 'Direct/other':
					referrer_icon = "icon-right-open";

					break;
				}
				document.getElementById("lead-detail-referrer").innerHTML = lead.customer_profile.behaviour["channel"];
				document.getElementById("lead-detail-referrer-icon").className = "item-icon "+referrer_icon;

				// Most Active on
				if (lead.customer_profile.most_active) {
					document.getElementById("lead-details-most-active-page-title").innerHTML = lead.customer_profile.most_active.title;
					document.getElementById("lead-details-most-active-page-stats").innerHTML = lead.customer_profile.most_active.first_visit_time_humanreadable;
					document.getElementById("lead-detail-most-active-page").classList.remove("hidden");
				} else {
					document.getElementById("lead-detail-most-active-page").classList.add("hidden");
				}

				//Referral detail
				document.getElementById("lead-detail-referrer-info-icon").className = referrer_icon+" item";
				document.getElementById("lead-details-referrer-title").innerHTML = lead.customer_profile.behaviour["channel"] ? lead.customer_profile.behaviour["channel"] : "Direct or unknown";
				document.getElementById("lead-details-referrer-url").innerHTML = lead.customer_profile.behaviour["referrer"] ? lead.customer_profile.behaviour["referrer"] : "Direct or unknown";

				if (lead.payload.customer_comments){
					if (!lead.customer_profile.additional_cards || lead.customer_profile.additional_cards.constructor !== Array)
						lead.customer_profile.additional_cards = [];

					lead.customer_profile.additional_cards.push(
						{"title": "Customer comments",
						 "icon":"chat",
						 "sections":[{"subtitle":"",
									  "detail": lead.payload.customer_comments}]
						}
					);
				}
				
				//additional cards as prescribed by the analytics API + customer comments
				if (lead.customer_profile.additional_cards && lead.customer_profile.additional_cards.constructor === Array){
					var card_container = document.getElementById("lead-additional-cards");
					var addn_cards_ml = "";
					for (var i=0; i < lead.customer_profile.additional_cards.length; i++){
						addn_cards_ml += "<div id='lead-detail-additional-"+i+"' class='card additional-card lead-detail-most-active-page' >"+
							"<div class='card-title'>"+lead.customer_profile.additional_cards[i]["title"]+"</div>";

						addn_cards_ml += "<div class='active-page'>";
						if (lead.customer_profile.additional_cards[i]["icon"])
							addn_cards_ml += "<div class='icon-"+lead.customer_profile.additional_cards[i]["icon"]+" item'></div>";

						if (lead.customer_profile.additional_cards[i]["sections"] && lead.customer_profile.additional_cards[i]["sections"].constructor === Array)
							for (var j=0; j < lead.customer_profile.additional_cards[i]["sections"].length; j++){
								addn_cards_ml += "<div class='page-detail item'><div id='lead-details-additional-"+i+"-title' class='page-title'>"+lead.customer_profile.additional_cards[i]["sections"][j]["subtitle"]+"</div>"+
									"<div id='lead-details-additional-"+i+"-info' class='page-stats'>"+lead.customer_profile.additional_cards[i]["sections"][j]["detail"].replace(/(\s*\n)+/g,"<br />")+"</div></div>";
							}

						addn_cards_ml += "</div></div></div>";
						
					}
					card_container.innerHTML = addn_cards_ml;
				}
				
				// web timeline
				var timeline = [];
				var next_visit;
				for(var i = lead.customer_profile.timeline.length - 1; i >= 0; i--) {
					var item = lead.customer_profile.timeline[i];

					if (item.type === "page-visit") {
						if (next_visit) {
							var diff = Math.abs(new Date(next_visit.first_visit_time_humanreadable) - new Date(item.first_visit_time_humanreadable));
							var minutes = Math.floor((diff/1000)/60);
						}

						//assemble the interaction data string
						var interaction_data = "";
						if (lead.customer_profile.pages[item.url].clicks){
							interaction_data += lead.customer_profile.pages[item.url].clicks+" click"+( lead.customer_profile.pages[item.url].clicks !== 1 ? "s" : "");
						}

						if (lead.customer_profile.pages[item.url].scrolls){
							if (interaction_data != "")
								interaction_data += ", ";
							interaction_data += lead.customer_profile.pages[item.url].scrolls+" scroll"+(lead.customer_profile.pages[item.url].scrolls !== 1 ? "s" : "");
						}

						if (lead.customer_profile.pages[item.url].touches){
							if (interaction_data != "")
								interaction_data += ", ";
							interaction_data += lead.customer_profile.pages[item.url].touches+" touch"+( lead.customer_profile.pages[item.url].touches !== 1 ? "es" : "");
						}

						if (interaction_data != "")
							interaction_data = "<span class='data'>Total: " + interaction_data + "</span>";

						timeline.push(
							"<li class='web-timeline-item'>" +
								"<span class='web-timeline-item-create-datetime'>" + item.first_visit_time_humanreadable + "</span>" +
								"<div class='card web-timeline-item-detail-container'>" +
								"<i class='icon-newspaper timeline-icon web-timeline-item-detail'></i>" + // TODO better as span
								"<div class='timeline-description web-timeline-item-detail'>Visited Page: " + (item.title ? item.title : item.url_full )+ "</div>" +
								"<span class='url'>"+item.url_full+"</span>"+
								interaction_data +
							//"<div class='page-stats'>" + (minutes || 0) + " mins | </div>" + // TODO mins what? move to fn
								"</div>" +
								"</li>"
						);

						next_visit = item;
					} else if (item.type === "raised-lead") {
						timeline.push(
							"<li class='web-timeline-item'>" +
								"<span class='web-timeline-item-create-datetime'>" + item.action_time_humanreadable + "</span>" +
								"<div class='card web-timeline-item-detail-container'>" +
								"<i class='icon-login timeline-icon web-timeline-item-detail'></i>" +
								"<div class='timeline-description web-timeline-item-detail'>Requested callback</div>" +
								"</div>" +
								"</li>"
						);
					} else if (item.type === "sales-person") {
						timeline.push(
							"<li class='web-timeline-item'>" +
								"<span class='web-timeline-item-create-datetime'>" + item.capture_time_humanreadable + "</span>" +
								"<div class='card web-timeline-item-detail-container'>" +
								"<i class='icon-users timeline-icon web-timeline-item-detail'></i>" +
								"<div class='timeline-description web-timeline-item-detail'>Sales Person: " + item.sales_person + "</div>" +
								"</div>" +
								"</li>"
						);
					}
				}

				document.getElementById("lead-detail-web-timeline").innerHTML = (timeline ?
																				 timeline.reduce(function (prev, curr) { // TODO is this  = timeline.join(""); ?
																						 prev += curr;
																					 return prev;
																				 }, "")
																				 : '');
				this.el.classList.remove("is-hidden");


				//check to see if a tutorial has been played for this screen
				var tuts = JSON.parse(localStorage.getItem("tutorials"));
				if (tuts == null || tuts.leaddetails != 1){
					if (tuts == null)
						tuts = {};
					tuts.leaddetails = 1;
					localStorage.setItem("tutorials", JSON.stringify(tuts));
					tutorial_overlay_component.show([{overlay_css: {width: "98%",
																	height: "10em",
																	top: "5em",
																	right: "0.5%",
																	"border-radius": "3px",
																	border: "3px solid rgb(255, 255, 255)"},
													  content_css: {top: "4em"},
													  content_txt: "Customer details are displayed here.<br/><small style='font-size: 0.4em;'>(Tap the box to move to the next step!)</small>"},
													 {overlay_css: {width: "50%",
																	height: "3.5em",
																	top: "9em",
																	right: "25%",
																	"border-radius": "3px",
																	border: "3px solid rgb(255, 255, 255)"},
													  content_css: {top: "3em"},
													  content_txt: "You can tap the map marker to launch a map viewer to show you where the prospect is"},
													 {overlay_css: {width: "95%",
																	height: "5em",
																	top: "15em",
																	right: "2.5%",
																	"border-radius": "3px",
																	border: "3px solid rgb(255, 255, 255)"},
													  content_css: {top: "4.5em"},
													  content_txt: "Tap the arrow to add or review your notes"},
													 {overlay_css: {width: "95%",
																	height: "auto",
																	top: "20em",
																	right: "2.5%",
																	bottom: "60px",
																	"border-radius": "3px",
																	border: "3px solid rgb(255, 255, 255)"},
													  content_css: {top:"0.2em"},
													  content_txt: "Review detailed analytics about the prospect"},
													 {overlay_css: {width: "95%",
																	height: "5em",
																	top: "auto",
																	bottom: "3px",
																	right: "2.5%",
																	"border-radius": "3px",
																	border: "3px solid rgb(255, 255, 255)"},
													  content_css: {top:"40%"},
													  content_txt: "When you're ready, contact the customer through phone, text or Skype!"},
													 {overlay_css: {width: "5em",
																	height: "5em",
																	top: "0.2em",
																	bottom: "auto",
																	right: "1em",
																	border: "3px solid rgb(255, 255, 255)",
																	"border-radius": "100%"},
													  content_css: {top: "1em"},
													  content_txt: "After you have spoken to the prospect, tap this button to keep the lead if you think it warrants follow up, or discard it if you think it does not need to be pursued!",
													  perform_action_on_click: function(){ appbar_component.context_actions_container.classList.toggle("is-hidden");}}]
												   );
				}
			},


			reshow: function () {
			},

			hide: function () {
				tabbar_component.show();
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
				if (a) {
					var thi = this;
					var context = {};
					if (a.saved_lead) {
						context = {
							context_button_icon_class: "icon-sliders", //"icon-paper-plane-empty",
							context_actions: [
								{
									button_props: {
										id: "lead-won-button",
										icon_class: "icon-thumbs-up",
										text: E.lt("lead-won")
									},
									button_action: function (e) {
										loader_overlay_component.show();

										api({
											promisify: true,
											action: "lead_won",
											queue_id: qms_tellerapp.teller.private_user_queue, //this should be in the user's private queue
											id: a.saved_lead.id
										}).then(function(response) {
											for (var i = 0; i < leads.saved.length; i++) {
												if (leads.saved[i] === a.saved_lead.id) {
													leads.saved = leads.saved.splice(i, 1);
													break;
												}
											}
											screens.show.leadslist(null, {hard_reload: true});
										}).catch(function(error) {
											console.log("Unable to release ticket", error);
										}).finally(function() {
											loader_overlay_component.hide();
										});
									}
								},
								{
									button_props: {
										id: "lead-transfer-button",
										icon_class: "icon-exchange",
										text: E.lt("transfer-ticket")
									},
									button_action: function (e) {
										lead_transfer_component.show({ service_id: a.saved_lead.service_id, ticket_id: a.saved_lead.id, is_private_queue: true });
									}
								},
								{
									button_props: {
										id: "lead-lost-button",
										icon_class: "icon-thumbs-down",
										text: E.lt("lead-lost")
									},
									button_action: function (e) {
										loader_overlay_component.show();

										api({
											promisify: true,
											action: "lead_lost",
											queue_id: qms_tellerapp.teller.private_user_queue, //lead should be in the teller's private queue
											id: a.saved_lead.id
										}).then(function () {
											for (var i = 0; i < leads.saved.length; i++) {
												if (leads.saved[i].id === a.saved_lead.id) {
													leads.saved.splice(i, 1);
												}
											}
											screens.show.leadslist();
										}).catch(function (error) {
											console.log("Not able to release", error);
										}).finally(function () {
											loader_overlay_component.hide(); // TODO error handling?
										});
									}
								},
								{
									button_props: {
										id: "analytics-refresh-button",
										icon_class: "icon-cw",
										text: E.lt("refresh")
									},
									button_action: function (e) {
										if (e.currentTarget.classList.contains("spin-refresh"))
											return;

										e.currentTarget.classList.add("spin-refresh");
										//pull the ticket out of the saved leads array
										var viewing_lead_id = document.getElementById("viewing_lead_id").value;
										var ticket;
										for (var i=0; i < leads.saved.length; i++){
											if (leads.saved[i].id == viewing_lead_id){
												ticket = leads.saved[i];
												break;
											}
										}
										if (typeof ticket != "undefined"){
											analytics({customer_id: ticket.payload.customer_id,
													   force_download: true,
													   handlers:{
														   ok: function (response) {
															   ticket.customer_profile = response.customer_profile;
															   if (document.body.classList.contains("screen-leaddetails")) //TODO - use our screen management methods so this is not hardcoded
																   thi.draw_lead(ticket);
															   e.currentTarget.classList.remove("spin-refresh");
														   },
														   not_ok: function (error) {
															   e.currentTarget.classList.remove("spin-refresh");
														   return false; //TODO error handling
														   }
													   }
													  });
										}
									}
								}
							]
						};

						appbar_component.back_button.state("unhidden");
					} else if (a.waiting_lead) {
						appbar_component.back_button.state("hidden");
						appbar_component.waiting_leads_count.classList.add("is-hidden");
						leaddetails_component.el.classList.add("new-lead");
						context = {
							context_button_icon_class: "icon-sliders",
							context_actions: [
								{
									button_props: {
										id: "lead-keep-button",
										icon_class: "icon-floppy",
										text: E.lt("lead-keep")
									},
									button_action: function (e) {
										loader_overlay_component.show();
										api({
											promisify: true,
											action: "lead_keep",
											id: a.waiting_lead.id,
											to_service_id: qms_tellerapp.queue_services[qms_tellerapp.teller.private_user_queue][0]
										}).then(function() {
											return get_ticket_list({ promisify: true });
										}).catch(function (error) {
											console.log("Unable to save lead", error.message);
										}).finally(function () {
											//TODO - add better error handling, it shouldn't just go back to the main screen if it was not successful
											loader_overlay_component.hide();
											screens.show.leadslist();
											leaddetails_component.el.classList.remove("new-lead");
											update_lead_notification();
										});
									}
								},
								{
									button_props: {
										id: "lead-discard-button",
										icon_class: "icon-trash",
										text: E.lt("lead-discard")
									},
									button_action: function (e) {
										loader_overlay_component.show();
										api({
											promisify: true,
											action: "lead_discard",
											id: a.waiting_lead.id
										}).then(function() {
											return get_ticket_list({ promisify: true });
										}).catch(function (error) {
											console.log("Unable to discard lead", error.message);
										}).finally(function () {
											//TODO - add better error handling, it shouldn't just go back to the main screen if it was not successful
											loader_overlay_component.hide();
											screens.show.leadslist();
											leaddetails_component.el.classList.remove("new-lead");
											update_lead_notification();
										});
									}
								}
							]
						};
					}

					appbar_component.load(context); // TODO if this is not the first call then it is show
				}

				tabbar_component.hide();

				// @formatter:off
				this.el.innerHTML =
					"<div class='lead-details'>" +
					"<input type='hidden' id='viewing_lead_id' />" + //used for saved leads only
					"<div id='lead-detail-header-simple' class='lead-detail-header-simple animated is-hidden'>" +
					"<div class='avatar-container lead-header-item'>" +
					"<div id='lead-detail-avatar-simple' class='avatar'></div>" +
					"</div>" +
					"<div class='lead-detail-info lead-header-item'>" +
					"<div id='lead-detail-name-simple' class='name'></div>" +
					"</div>" +
					"</div>" +

				"<div id='lead-detail-header' class='lead-detail-header lead-detail-item'>" +
					"<div class='avatar-container lead-header-item'>" +
					"<div id='lead-detail-avatar' class='avatar'></div>" +
					"</div>" +
					"<div class='lead-detail-info lead-header-item'>" +
					"<div id='lead-detail-name' class='name'></div>" +
					"<div id='lead-detail-location' class='location'></div>" +
					"<div id='lead-detail-company' class='company'></div>" +
					"<div id='lead-detail-service' class='company'></div>" +
					"</div>" +
					"<div class='lead-freshness lead-header-item'>" +
					"<div class='lead-detail-datetime-claimed-label'>Claimed On</div>" +
					"<div id='lead-detail-datetime-claimed' class='lead-detail-datetime-claimed'></div>" +
					"<div class='lead-detail-datetime-claimed-label'>Analytics from</div>" +
					"<div id='lead-detail-datetime-analytics' class='lead-detail-datetime-claimed'></div>" +
					"</div>" +
					"</div>" +

				"<div class='card toggle-text-area'>" +
					"<div class='note lead-detail-notes'>" +
					"<div id='collapsed-notes-container' class='collapsed-notes'>" +
					"<i class='icon-attach collapsed-notes-item'></i>" +
					"<div id='collapsed-notes-label' class='collapsed-notes-label collapsed-notes-item'>Notes</div>" +
					"<div id='notes-expand' class='collapsed-notes-item'></div>" +
					"<div id='lead-notes-input-container' class='lead-notes-input-container is-hidden'>" +
                    "<textarea id='lead-notes-input' class='lead-notes-input'></textarea>" +
                    "<div id='lead-notes-save-button-container' class='lead-notes-save-button-container'></div>" +
					"</div>" +
					"</div>" +
					"</div>" +
					"</div>" +

				"<div id='lead-detail-number-info' class='card lead-detail-most-active-page'>"+
					"<div class='card-title'>"+E.lt("person-contact-details")+"</div>" +
					"<div class='active-page'>" +
						"<div class='icon-phone item'></div>" +
						"<div class='page-detail item'>" +
							"<div id='lead-detail-contact-telephone' class='page-title'></div>" +
							"<div id='lead-detail-contact-telephone-stats' class='page-stats'></div>" +
					"</div>" +
					"<div class='active-page' id='lead-detail-number-info-email-pane'></div>"+
					"</div> </div>" +

				"<div id='lead-detail-engagement-summary' class='card lead-detail-engagement-summary'>" +
					"<div class='item'>" +
					"<div id='engagement-label-1' class='item-label'></div>" +
					"<div id='engagement-metric-1' class='item-value'></div>" +
					"</div>" +
					"<div class='item'>" +
					"<div id='engagement-label-2' class='item-label'></div>" +
					"<div id='engagement-metric-2' class='item-value'></div>" +
					"</div>" +
					"<div class='item'>" +
					"<div id='engagement-label-3' class='item-label'></div>" +
					"<div id='engagement-metric-3' class='item-value'></div>" +
					"</div>" +
					"</div>" +

				"<div id='lead-detail-activity-highlights' class='card lead-detail-activity-highlights'>" +
					"<div class='item'>" +
						"<div id='lead-detail-device-type-icon' class='item-icon'></div>" +
						"<div class='item-label'><small id='lead-detail-device-type'>Mobile</small></div>" +
					"</div>" +
					"<div class='item'>" +
						"<div id='lead-detail-os-icon' class='item-icon'></div>" +
						"<div class='item-label'><small id='lead-detail-os'>iOS</small></div>" +
					"</div>" +
					"<div class='item'>" +
						"<div id='lead-detail-browser-icon' class='item-icon'></div>" +
						"<div class='item-label'><small id='lead-detail-browser'>Chrome</small></div>" +
					"</div>" +
					"<div class='item'>" +
						"<div id='lead-detail-referrer-icon' class='item-icon icon-google'></div>" +
						"<div class='item-label'><small id='lead-detail-referrer'></small></div>" +
					"</div>" +
				"</div>" +

				"<div id='lead-detail-most-active-page' class='card lead-detail-most-active-page' >" +
					"<div class='card-title'>"+E.lt("most-active-on")+"</div>" +
					"<div class='active-page'>" +
						"<div class='icon-newspaper item'></div>" +
						"<div class='page-detail item'>" +
							"<div id='lead-details-most-active-page-title' class='page-title'></div>" +
							"<div id='lead-details-most-active-page-stats' class='page-stats'></div>" +
						"</div>" +
					"</div> </div>" +

				"<div id='lead-detail-referrer-info' class='card lead-detail-most-active-page' >" +
					"<div class='card-title'>"+E.lt("referrer-info")+"</div>" +
					"<div class='active-page'>" +
						"<div id='lead-detail-referrer-info-icon' class='item'></div>" +
						"<div class='page-detail item'>" +
							"<div id='lead-details-referrer-title' class='page-title'></div>" +
							"<div id='lead-details-referrer-url' class='page-stats'></div>" +
						"</div>" +
					"</div> </div>" +

				"<div id='lead-additional-cards'></div>"+ //additional placeholder for any new cards that need to be added direct from the analytics response

				"<div class='divider'><span>Timeline</span></div>" +

				"<div class='lead-detail-web-timeline-container'>" +
					"<ul id='lead-detail-web-timeline' class='lead-detail-web-timeline'></ul>" +
					"</div>" +

				"<div class='lead-contact-actions-container tabbar'>" +
					"<div id='lead-contact-actions' class='lead-contact-actions contact-actions'>" +
					"<div id='contact-action-sms-container' class='contact-actions-container'></div>" +
					"<div id='contact-action-call-container' class='contact-actions-container'></div>" +
					"<div id='contact-action-skype-container' class='contact-actions-container'></div>" +
					"<div id='contact-actions-more-overflow-container' class='contact-actions-container contact-actions-more-overflow-container'></div>" +
					"</div>" +
					"<div id='lead-contact-more-actions' class='lead-contact-more-actions contact-more-actions'></div>" +
					"</div>" +

				"</div>";
			},

			load: function (a) {
				return true;
			}
		};

		//=================================================================================================
		groupactivity_component = {
			el: BL.container_el("groupactivity", "screen is-hidden"),
			show: function (a) {

				var day_arr = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]; //TODO to be moved into JS langtext
				var month_arr = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]; //TODO to be moved into JS langtext

				var self = this;
				var group_activity_report_key = 'report-51';
				var dt_now = new Date();

				if (qms_tellerapp && qms_tellerapp.report && qms_tellerapp.report[group_activity_report_key]) {
					var group_activity = qms_tellerapp.report[group_activity_report_key];
					var timeline_data = group_activity.data
						.map(function (activity) {
							return activity.reduce(function (prev, curr, idx) {
								prev[group_activity.headings[idx]] = curr;
								return prev
							}, {})
						});
					//add the site visit data to this timeline array
					for (var i=0; i < (group_activity.visit_data.length - 1); i++){
						//look ahead to determine the percentage change between today and yesterday
						var delta = group_activity.visit_data[i].visitors / group_activity.visit_data[i+1].visitors;
						var change;
						if (delta < 1){
							change = "-" + Math.round((1 - delta)*100) + "%";
						}else if (delta > 1){
							change = "+" + Math.round((delta - 1)*100) + "%";
						}else{
							change = "0%";
						}

						var date_arr_component = group_activity.visit_data[i].date.split("-");
						var js_date = new Date (date_arr_component[0], date_arr_component[1]-1, date_arr_component[2], 23,59,59);

						timeline_data.push({status: "visit-metric",
											visits: group_activity.visit_data[i].visitors,
											change: change,
											is_better: delta > 1 ? true : false,
											altered_when: (js_date.getTime()/1000)});
					}

					//sort the array with the visit data now inside
					timeline_data.sort(function (a,b){
						return (b.altered_when - a.altered_when);
					});

					var curr_date = "";
					var visit_data = qms_tellerapp.report[group_activity_report_key]["visit_data"];
					var visit_data_pos = 0;
					var timeline = [];
					timeline_data.forEach(function (item, idx) {
						var altered_on = new Date(parseInt(item.altered_when, 10)*1000); // TODO poor names and all should be moved to a better fn

						var second_diff = Math.floor(dt_now.getTime() - altered_on.getTime())/1000;
						var time_diff, time_diff_text;

						//check if the date is the same one
						var day = day_arr[altered_on.getDay()];
						var cal_date = altered_on.getDate();
						var month = month_arr[altered_on.getMonth()];

						if (curr_date != day + ' ' + cal_date + ' ' + month){
							curr_date = day + ' ' + cal_date + ' ' + month

							if (timeline.length == 0)
								timeline.push("<div class='vertical-timeline-header'><div class='vertical-timeline-day'>"+day + ' ' + cal_date + ' ' + month+"</div></div><ul class='vertical-timeline'>");
							else
								timeline.push("</ul><div class='vertical-timeline-day'>"+day + ' ' + cal_date + ' ' + month+"</div><ul class='vertical-timeline'>");
						}


						/* Lead action time */
						if (second_diff < 60) {
							//time_diff = second_diff;
							//time_diff_text = "sec";
							time_diff = "";
							time_diff_text = "Less than 1 min";
						} else if (second_diff < 3600) {
							time_diff = Math.floor(second_diff / 60);
							time_diff_text = "min";
						} else {
							time_diff = format_to_readable_time(altered_on);
							time_diff_text = ""
						}

						if (time_diff === parseInt(time_diff, 10)) {
							time_diff_text += (time_diff > 1 ? "s ago" : " ago");
						}

						/* Lead status text */
						var lead_status, lead_summary, lead_location, lead_service, item_type, summary={};

						switch (item.status.toLowerCase()) {
						case 'new':
							lead_status = 'NEW LEAD RAISED';
							lead_summary = (item.name ? item.name + ' REQUESTED A CALL' : lead_status);
							lead_location = (item.location ? item.location : '');
							lead_service = (item ? item.service : '');
							item_type = 'action';
							break;

						case 'processing':
							lead_status = 'LEAD CLAIMED';
							lead_summary = ('BY ' + (item.teller_fullname || item.teller || item.whowhere));
							lead_location = ''; //(payload ? payload.location : '');
							lead_service = ''; //(payload ? payload.service : '');
							item_type = 'action'
							break;

						case 'visit-metric':
							summary.left_top = item.visits;
							summary.left_bottom = "VISITOR" + (item.visits == 1 ? "" : "S");
							summary.right_top = item.change;
							summary.right_bottom = "CHANGE";
							summary.classes = item.is_better ? "yellow" : "";
							item_type='summary';
							break;

						default:
							lead_status = item.status;
						}

						/* Direction on timeline */
						var timeline_item_direction = (idx % 2 === 0 ? "timeline-item-left" : "timeline-item-right");
						var location_ml = "";
						if (lead_location) {
							if (idx % 2 === 0) {
								location_ml = "<small><i class='icon-location'></i>" + lead_location + "</small>";
							} else {
								location_ml = "<small>" + lead_location + "<i class='icon-location'></i></small>";
							}
						}
						var service_ml = lead_service ? "<small>Requested " + lead_service + "</small>" : "";

						if (item_type=='action'){
							timeline.push(
								"<li>" +
									"<div class='" + timeline_item_direction + "'>" +
									"<div class='timeline-item'>" +
									"<div class='timeline-item-header'>" +
									"<span class='timeline-item-timestamp'>" + time_diff + " " + time_diff_text + "</span>" +
									"<span class='timeline-item-lead-status'>" + lead_status + "</span>" +
									"<span class='timeline-item-lead-summary'>" + lead_summary + "</span>" +
									"</div>" +
									"<div class='timeline-item-details'>" +
									location_ml +
									service_ml +
									"</div>" +
									"</div>" +
									"</div>" +
									"</li>"
							);
						}else if (item_type == 'summary'){
							timeline.push(
								"<li>" +
									"<div class='" + timeline_item_direction + "'>" +
									"<div class='timeline-item'>" +
									'<div class="bottomBlock '+summary.classes+'">' +
									'<div class="leftBlock">'+
									'<div class="top">'+summary.left_top+'</div>'+
									'<div class="bottom">'+summary.left_bottom+'</div>'+
									'</div>'+
									'<div class="rightBlock">'+
									'<div class="top">'+summary.right_top+'</div>'+
									'<div class="bottom">'+summary.right_bottom+'</div>'+
									'</div>'+
									'</div>'+
									"</div></div>" +
									"</li>");
						}
					});
				}

				this.el.innerHTML =
					"<div class='group-activity'>" +
					"<div class='vertical-timeline-container'>" +
					"<div class='vertical-timeline-up-container'></div>" +
					//"<div id='group-activity-refresh-container'></div>" +
					/*"<div class='vertical-timeline-header'>" +
					"<div class='vertical-timeline-day'>Recent</div>" +// TODO i18n

					"</div>" +
					"<ul class='vertical-timeline'>" +*/
					(timeline ?
					 timeline.reduce(function (prev, curr) {
						 prev += curr;
						 return prev;
					 }, "")
					 : '') +
					"</ul>" +
					"<div class='vertical-timeline-footer'></div>" +
					"<div class='vertical-timeline-scroll-down-container'></div>" +
					"</div>" +
					"</div>";

				/*new BL.el.Button({
					id: "group-activity-refresh",
					text: "",
					classes: "icon-cw",
					place: "group-activity-refresh-container",
					click: function (b) {
						var animation_secs = 1;
						b.currentTarget.classList.add("animate-spin-" + animation_secs);
						// get_recent_group_activity(function (success, err) {
						//   if (err) {
						//     // TODO
						//   }
						//
						//   setTimeout(function () {
						//     b.currentTarget.classList.remove("animate-spin-" + animation_secs);
						//     self.reshow();
						//   }, animation_secs * 1000);
						// });
					}
				});*/

				// this.scroll_up_button = new BL.el.Button({
				//   id: "group-activity-up",
				//   text: "",
				//   classes: "icon-angle-up vertical-timeline-up",
				//   place: "group-activity-up-container",
				//   click: function (b) {
				//     var self = this;
				//     scrollToY(0, 1000, 'easeInOutSine', function () {
				//       self.state("hidden")
				//       groupactivity_component.scroll_down_button.state("unhidden");
				//     });
				//   }
				// });
				// this.scroll_up_button.state("hidden");

				this.scroll_down_button = new BL.el.Button({
					id: "group-activity-down",
					text: "",
					classes: "icon-down-open vertical-timeline-down",
					place: "group-activity-scroll-down-container",
					click: function (b) {
						scrollToY(document.getElementById('groupactivity').scrollHeight, 1000, 'easeInOutSine', function () {
							// self.state("hidden")
							// groupactivity_component.scroll_up_button.state("unhidden");
						});
					}
				});

				this.el.classList.remove("is-hidden");
			},

			reshow: function () {
				this.show();
			},

			hide: function () {
				this.el.innerHTML = "";
				this.el.classList.add("is-hidden");
			},
			before_show_hook: function (a) {
				thi = this;
				//appbar_component.back_button.state("unhidden"); // TODO this is partial state undo, should use "normal"
				appbar_component.load({	// TODO this is a show () (and why in before show? violates usage pattern) because it is not the first call (which was when loading the screens). it is also in the leadslist screen, and the leadslist screen show will call appbar_component.show() again but without any args not much happens except unhide. this will receive screen meta when it is reshown so it can customize itself.
					context_button_icon_class: "icon-cog",
					context_actions: [{
						button_props: {
							id: "group-refresh-button",
							icon_class: "icon-cw",
							text: E.lt("refresh")
						},
						button_action: function (e) {
							if (e.currentTarget.classList.contains("spin-refresh"))
								return;

							e.currentTarget.classList.add("spin-refresh");

							get_recent_group_activity().then(function (r) {
								if (document.body.classList == "screen-groupactivity"){
									thi.reshow();
									e.currentTarget.classList.remove("spin-refresh");
								}
							});
						}
					}]
				});

				appbar_component.back_button.state("hidden");
			},
			load: function (a) {
				return true;
			}
		};

		//=================================================================================================
		new_lead_notification_component = {
			el: BL.container_el("newleadnotification", "modal-overlay is-hidden"),
			show: function () {
				this.el.classList.remove("is-hidden");
			},

			reshow: function () {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
			},

			load: function (a) {
				var self = this;
				this.el.innerHTML =
					"<div class='modal-content'>" +
					"<div id='lead-claim-container' class='lead-claim-container'>" +
					"<div>" +
					"<div id='lead-claim-picture-container' class='avatar-container'>" +
					"<div id='lead-claim-picture' class='avatar'>" +
					"<i class='avatar-pic'></i>" +
					"</div>" +
					"</div>" +
					"<div id='lead-claim-text' class='lead-claim-text'>" + E.lt("new-lead-notification-text") + "</div>" +
					"</div>" +
					"<div id='lead-claim-buttons'></div>" +
					"</div>" +
					"</div>";

				new BL.el.Button({
					id: "lead-claim-button",
					text: E.lt("lead-claim-now"),
					classes: "lead-action-button lead-claim-button",
					place: "lead-claim-buttons",
					click: function (a) {
						//TODO: Disable other buttons
						this.state("processing", { visual_delay_ms: 250 });
						var thi_button = this;

						//var queue_services = qms_tellerapp.queue_services;
						//var waiting_ticket_id = leads.waiting[0].id;
						var waiting_ticket_queue_id = leads.waiting.queue_ids[0];

						/*for (var queue_id in queue_services) {
							if (queue_services.hasOwnProperty(queue_id)) {
								if (queue_services[queue_id] && queue_services[queue_id].length > 0) {
									var matching_queue = queue_services[queue_id].find(function (service_id) {
										return (service_id === waiting_ticket_service_id);
									});
									if (matching_queue) {
										var waiting_ticket_queue_id = queue_id;
										break;
									}
								}
							}
						}*/

						loader_overlay_component.show();
						screens.show.leadslist();
						api({
							promisify: true,
							action: "lead_get_next",
							queue_id: waiting_ticket_queue_id
						}).then(function (ticket) {
							if (typeof ticket != 'undefined' && ticket.status === "ok" && ticket.id > 0) {
								screens.show.leaddetails(null, { waiting_lead: ticket });
								self.hide();
								loader_overlay_component.hide();
							} else if (typeof response != 'undefined' && response.status == 'limits') {
								E.flash_element_class(thi_button.el(), "e-unsuccessful-1", 1000);
								thi_button.statetimer("normal", 1000);
								screens.show.licenselimits(null, {headline: "You need to upgrade to view new leads!",
														   explain: "This lead is waiting for you, but you are currently on our free plan. You can upgrade online to instantly get access to the waiting prospect, or you can wait until XXXX when you will be able to access 10 more leads.",
														   ps: "P.S. Congratulations! Your business is getting an outstanding number of leads!"});
								loader_overlay_component.hide();
							} else {
								E.flash_element_class(thi_button.el(), "e-unsuccessful-1", 1000);
								thi_button.statetimer("normal", 1000);

								console.log("Unsuccesful in grabbing lead", ticket);
								get_recent_group_activity().then(function(){
									screens.show.groupactivity();
									self.hide();
									loader_overlay_component.hide();
								});
							}
						}).catch(function (error) {
							console.log("Unable to claim lead", error.message);
							get_recent_group_activity().then(function(){
								screens.show.groupactivity();
								self.hide();
								loader_overlay_component.hide();
							});
						}).finally(function() {
							//loader_overlay_component.hide();
						});
					}
				});

				document.body.onmouseup = function (e) {
					if (!document.getElementById("lead-claim-container").contains(e.target)) {
						self.hide();
					}
				};

				this.el.classList.remove("is-hidden");
				return true;
			}

		};
        
		//=================================================================================================
		lead_transfer_component = {
			el: BL.container_el("leadtransfer", "modal-overlay is-hidden"),
			show: function (a) {
				var self = this;
				var services = qms_tellerapp.teller.services;
				var queue_transfers = qms_tellerapp.teller.queue_transfers[qms_tellerapp.teller.private_user_queue][a.service_id];

				if (queue_transfers && queue_transfers.hasOwnProperty('transfer-service-ids')) {
					this.el.innerHTML =
						"<div class='modal-content'>" +
						"<div id='lead-transfer-container' class='lead-transfer-container'>" +
						"<div class='label'>Please select a service to transfer to</div>" +
						"<div id='lead-transfer-services-container' class='lead-transfer-services-container'></div>" +
						"</div>" +
						"</div>";

					var lead_transfer_services_container = document.getElementById("lead-transfer-services-container");
					var transfer_services = queue_transfers["transfer-service-ids"];

					for (var i = 0; i < transfer_services.length; i++) {
						if (qms_tellerapp.queue_services[qms_tellerapp.teller.private_user_queue]) {
							for (var ii = 0; ii < qms_tellerapp.queue_services[qms_tellerapp.teller.private_user_queue].length; ii++) {
								if (qms_tellerapp.queue_services[qms_tellerapp.teller.private_user_queue][ii] !== transfer_services[i] &&
									!services[transfer_services[i]].config.private_user_service) { //TODO add check to determine if this is someone else's private queue as well, if it is, then do not display the option to transfer there
									new BL.el.Button({
										id: "transfer-service-id-" + transfer_services[i],
										text: services[transfer_services[i]].title,
										classes: "bl-button",
										attrs: "data-service-id=" + transfer_services[i] + " data-ticket-id=" + a.ticket_id,
										place: lead_transfer_services_container,
										click: function (e) {
											var service_id = e.currentTarget.getAttribute("data-service-id");
											var ticket_id = e.currentTarget.getAttribute("data-ticket-id");

											loader_overlay_component.show();
											api({
												promisify: true,
												action: "lead_transfer",
												id: ticket_id,
												queue_id: qms_tellerapp.teller.private_user_queue,
												to_service_id: service_id,
											}).then(function(response) {
												return get_ticket_list({ promisify: true });
											}).then(function (tickets) {
												if (tickets && tickets.length > 0) {
													saved_leads.remove(saved_leads.id_find({ id: parseInt(ticket_id) }));
													update_lead_notification();
												}
												self.hide();
												screens.show.leadslist();
											}).catch(function (error) {
												console.log("Unable to transfer lead", error.message);
											}).finally(function () {
												loader_overlay_component.hide();
											});
										}
									});
								}
							}
						}
					}

					new BL.el.Button({
						id: "transfer-service-modal-cancel",
						text: E.lt("cancel"),
						classes: "button-danger",
						place: lead_transfer_services_container,
						click: function (e) {
							self.hide();
						}
					});
				}

				document.body.onmouseup = function (e) {
					if (!document.getElementById("lead-transfer-services-container").contains(e.target)) {
						self.hide();
					}
				};

				this.el.classList.remove("is-hidden");
			},

			reshow: function () {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
			},

			load: function (a) {
				return true;
			}
		};

		//=================================================================================================
		loader_overlay_component = {
			el: BL.container_el("loader-overlay", "loader-overlay is-hidden"),
			show: function () {
				this.el.classList.remove("is-hidden");
			},

			reshow: function () {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
			},

			load: function (a) {
				this.el.innerHTML =
					"<div class='modal-content'>" +
					"<div class='loading loading-transparent animated' />" +
					"</div>";
				return true;
			}
		};

		//=================================================================================================
		tutorial_overlay_component = {
			el: BL.container_el("tutorial-overlay", "tutorial-overlay is-hidden"),
			show: function (a) {

				//restrict scrolling
				var fn_preventDefault = function(e){ e.preventDefault()};
				document.body.scrollTop=0; //move to the top
				document.body.setAttribute("style",'overflow-y: hidden;'); //disable scroll capability
				this.el.addEventListener('touchmove', fn_preventDefault); //for mobile

				this.el.classList.remove("is-hidden");
				this._tutorial_step = 0;
				this._steps = a;
				var thi = this;
				var highlighter = document.getElementById("tutorial-highlight");
				var content_box = document.getElementById("tutorial-content");

				//render the first tutorial step
				var render_step = function (s){
					/*
					  step format:
					  { overlay_css: {css props},
					    content_css: {css props},
						content_txt: txt,
						perform_action_on_click: fn}
					 */

					//extract styles from submission
					var o_css_style = '';
					for (prop in s.overlay_css){
						if (s.overlay_css.hasOwnProperty(prop)){
							o_css_style += prop+': '+s.overlay_css[prop]+'; ';
						}
					}

					//apply styles for the highlighter
					highlighter.setAttribute("style", o_css_style);

					var content_style = '';
					for (prop in s.content_css){
						if (s.content_css.hasOwnProperty(prop)){
							content_style += prop+': '+s.content_css[prop]+'; ';
						}
					}
					//apply styles for the highlighter
					content_box.setAttribute("style", content_style);
					//apply text
					content_box.innerHTML = s.content_txt;
				};

				//render the first step
				render_step(this._steps[this._tutorial_step]);

				document.getElementById("tutorial-highlight").addEventListener("click", function(e){
					if (typeof thi._steps[thi._tutorial_step].perform_action_on_click == 'function')
						setTimeout(function (){
							//execute the provided action
							thi._steps[thi._tutorial_step].perform_action_on_click();
						}, 10);

					if (thi._tutorial_step < (thi._steps.length - 1)){
						//there are more steps in the tutorial execute them
						thi._tutorial_step++;
						render_step(thi._steps[thi._tutorial_step]);
					}else{
						//no more steps, wipe content+listeners and end tutorial
						thi.hide();
						document.body.setAttribute("style",''); //restore scrolling
						thi.el.removeEventListener("touchmove", fn_preventDefault); //remove scroll limiter for mobile
						thi.el.innerHTML = "<div id='tutorial-highlight'></div>" +
							"<div id='tutorial-content'></div>";
					}
				});


			},

			reshow: function () {
			},

			hide: function () {
				this.el.classList.add("is-hidden");
			},

			before_show_hook: function (a) {
			},

			load: function (a) {
				this.el.innerHTML =
					"<div id='tutorial-highlight'></div>" +
					"<div id='tutorial-content'></div>";

				return true;
			}
		};

		//=================================================================================================
		screens.add({ screenboxes: "login", componentblock: login_component });

		screens.add({ screenboxes: "licenselimits", componentblock: appbar_component });
		screens.add({ screenboxes: "licenselimits", componentblock: licenselimits_component });
		screens.add({ screenboxes: "licenselimits", componentblock: tabbar_component });

		screens.add({ screenboxes: "leadslist", componentblock: appbar_component });
		screens.add({ screenboxes: "leadslist", componentblock: leadslist_component }); // TODO appbar_component is updated in this before show
		screens.add({ screenboxes: "leadslist", componentblock: tabbar_component });

		screens.add({ screenboxes: "leaddetails", componentblock: appbar_component });
		screens.add({ screenboxes: "leaddetails", componentblock: leaddetails_component }); // TODO appbar_component is updated in this before show
		screens.add({ screenboxes: "leaddetails", componentblock: tabbar_component });

		screens.add({ screenboxes: "groupactivity", componentblock: appbar_component });
		screens.add({ screenboxes: "groupactivity", componentblock: groupactivity_component });
		screens.add({ screenboxes: "groupactivity", componentblock: tabbar_component });

		screens.add({ screenboxes: "loaderoverlay", componentblock: loader_overlay_component }); // TODO why is this here? the screen is never used
		screens.add({ screenboxes: "tutorialoverlay", componentblock: tutorial_overlay_component });

		screens.load();
	}
};
