#!/usr/bin/env node

// each object in the array consists of a key which refers to the source and
// the value which is the destination.
var filestocopy = [{
    "resources/common/sounds/happy.mp3":
    "platforms/android/res/raw/happy.mp3"
}, {
    "resources/common/sounds/happy.mp3":
    "platforms/ios/Lucep/happy.mp3"
}, {
    "resources/common/sounds/airhorn.mp3":
    "platforms/android/res/raw/airhorn.mp3"
}, {
    "resources/common/sounds/airhorn.mp3":
    "platforms/ios/Lucep/airhorn.mp3"
}, {
    "resources/common/sounds/level_up.mp3":
    "platforms/android/res/raw/level_up.mp3"
}, {
    "resources/common/sounds/level_up.mp3":
    "platforms/ios/Lucep/level_up.mp3"
}, {
    "resources/common/sounds/perky.mp3":
    "platforms/android/res/raw/perky.mp3"
}, {
    "resources/common/sounds/perky.mp3":
    "platforms/ios/Lucep/perky.mp3"
}, {
    "resources/common/sounds/spritely.mp3":
    "platforms/android/res/raw/spritely.mp3"
}, {
    "resources/common/sounds/spritely.mp3":
    "platforms/ios/Lucep/spritely.mp3"
}];

var fs = require('fs');
var path = require('path');

// no need to configure below
var rootdir = process.argv[2];

filestocopy.forEach(function(obj) {
    Object.keys(obj).forEach(function(key) {
        var val = obj[key];
        var srcfile = path.join(rootdir, key);
        var destfile = path.join(rootdir, val);
        //console.log("copying "+srcfile+" to "+destfile);
        var destdir = path.dirname(destfile);
        if (fs.existsSync(srcfile) && fs.existsSync(destdir)) {
            fs.createReadStream(srcfile).pipe(
               fs.createWriteStream(destfile));
        }
    });
});
